
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <cstdlib>
#include <iostream>
#include <string>

#include <boost/context/all.hpp>
#include <boost/move/move.hpp>

void fn()
{
    std::cout << "inside function fn(): fn() returns return to main()" << std::endl;
}

int main( int argc, char * argv[])
{
    {
        boost::contexts::protected_stack stack( boost::contexts::stack_helper::default_stacksize());
        boost::contexts::context<> ctx( fn, boost::move( stack), false, true);

        ctx.resume();
    }

    std::cout << "Done" << std::endl;

    return EXIT_SUCCESS;
}
