//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <stdexcept>
#include <string>
#include <vector>

#include <boost/assert.hpp>
#include <boost/exception_ptr.hpp>
#include <boost/test/unit_test.hpp>
#include <boost/utility.hpp>

#include <boost/yield_iterator.hpp>

class string_adapter : public boost::yield_adapter< char >
{
private:	
	std::string   str_;

public:
	string_adapter( std::string const& str) :
        boost::yield_adapter< char >( true),
		str_( str)
	{}

	void iterate()
	{
        const char * c( str_.c_str() );
        while ( '\0' != * c) {
			const char tmp( * c);
			yield_return( tmp);
            ++c;
		}
	}
};

class pointer_adapter : public boost::yield_adapter< const char * >
{
private:	
    std::vector< const char* >   vec_;

public:
	pointer_adapter( std::vector< const char* > const& vec) :
        boost::yield_adapter< const char* >( true),
		vec_( vec)
	{}

	void iterate()
	{
        std::vector< const char* >::iterator i( vec_.begin() ), e( vec_.end() );
        while ( i != e)
        {
            yield_return( * i);
            ++i;
        }
	}
};

struct my_exception : public std::runtime_error
{
    my_exception() : std::runtime_error("my_excpetion")
    {}
};

struct throwing_adapter : public boost::yield_adapter< char >
{
    bool  do_throw;

	throwing_adapter( int) :
        boost::yield_adapter< char >( true),
        do_throw( false)
	{}

	void iterate()
	{
        for (;;)
        {
            if ( do_throw) boost::throw_exception( my_exception() );
            const char c('\0');
            yield_return( c);
            do_throw = true;
        }
    }
};

void test_case_1()
{
	std::string str("abc");
	boost::yield_iterator< string_adapter > i( str);
	boost::yield_iterator< string_adapter > e;

    BOOST_CHECK( i == boost::yield_iterator< string_adapter >( str) );
    BOOST_CHECK( e == boost::yield_iterator< string_adapter >() );

    BOOST_CHECK( i != e);
    ++i;
    BOOST_CHECK( i != e);
    ++i;
    BOOST_CHECK( i != e);
    ++i;
    BOOST_CHECK( i == e);
}

void test_case_2()
{
	std::string str("abc");
	boost::yield_iterator< string_adapter > i( str);
	boost::yield_iterator< string_adapter > e;

    BOOST_CHECK_EQUAL( 'a', * i);
    ++i;
    BOOST_CHECK_EQUAL( 'b', * i);
    ++i;
    BOOST_CHECK_EQUAL( 'c', * i);
}

void test_case_3()
{
	const char * str = "abc";
    std::vector< const char* > vec;
    vec.push_back( str);
	boost::yield_iterator< pointer_adapter > i( vec);
	boost::yield_iterator< pointer_adapter > e;

    BOOST_CHECK_EQUAL( str, * i);
}

void test_case_4()
{
	boost::yield_iterator< throwing_adapter > i( 0);

    BOOST_CHECK_THROW( ++i, my_exception);
}

boost::unit_test::test_suite * init_unit_test_suite( int, char* [])
{
    boost::unit_test::test_suite * test =
        BOOST_TEST_SUITE("Boost.Yield_Iterator: yield_iterator test suite");

    test->add( BOOST_TEST_CASE( & test_case_1) );
    test->add( BOOST_TEST_CASE( & test_case_2) );
    test->add( BOOST_TEST_CASE( & test_case_3) );
    test->add( BOOST_TEST_CASE( & test_case_4) );

    return test;
}
