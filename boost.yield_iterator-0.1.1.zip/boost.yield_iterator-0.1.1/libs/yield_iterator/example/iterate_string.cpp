
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <cstdlib>
#include <iostream>
#include <string>

#include <boost/yield_iterator.hpp>

class string_adapter : public boost::yield_adapter< char >
{
private:	
	std::string   str_;

public:
	string_adapter( std::string const& str) :
        boost::yield_adapter< char >( true),
		str_( str)
	{}

	void iterate()
	{
        const char * c( str_.c_str() );
        while ( '\0' != * c) {
			const char tmp( * c);
			yield_return( tmp);
            ++c;
		}
	}
};

int main( int argc, char * argv[])
{
	{
		std::string str("Hello World!");
		boost::yield_iterator< string_adapter > i( str);
		boost::yield_iterator< string_adapter > e;
        while ( i != e)
        {
            std::cout << * i << std::endl;
            ++i;
        }
	}

	std::cout << "\nDone" << std::endl;

	return EXIT_SUCCESS;
}
