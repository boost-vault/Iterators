
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <string>

#include <boost/yield_iterator.hpp>

#include "tree.h"

class tree_adapter : public boost::yield_adapter< leaf >,
                     public visitor
{
private:
    node::ptr_t     root_;

public:
    tree_adapter( node::ptr_t root) :
        boost::yield_adapter< leaf >( true),
        root_( root)
    { BOOST_ASSERT( root_); }

    void visit( branch & b)
    {
        if ( b.left) b.left->accept( * this);
        if ( b.right) b.right->accept( * this);
    }

    void visit( leaf & l)
    { yield_return( l); }

	void iterate()
    { root_->accept( * this); }
};

node::ptr_t create_tree()
{
    return branch::create(
        leaf::create( "A"),
        branch::create(
            leaf::create( "B"),
            leaf::create( "C") ) );
}

int main( int argc, char * argv[])
{
    {
        node::ptr_t root = create_tree();
		boost::yield_iterator< tree_adapter > e;
        for (
				boost::yield_iterator< tree_adapter > i( root);
				i != e; ++i) {
            std::cout << i->value <<  " ";
        }
    }

    std::cout << "\nDone" << std::endl;

    return EXIT_SUCCESS;
}
