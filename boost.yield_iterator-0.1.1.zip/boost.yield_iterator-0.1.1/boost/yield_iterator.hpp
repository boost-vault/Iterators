
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_YIELD_ITERATOR_H
#define BOOST_YIELD_ITERATOR_H

#include <cstddef>
#include <iterator>

#include <boost/config.hpp>
#include <boost/exception_ptr.hpp>
#include <boost/preprocessor/repetition.hpp>

#include <boost/context/all.hpp>

# if defined(BOOST_MSVC)
# pragma warning(push)
# pragma warning(disable:4355)
# endif

namespace boost {

template< typename T >
class yield_adapter
{
private:
    template< typename U >
    friend class yield_iterator;

    std::size_t                    use_count_;
    boost::contexts::context<>     ctx_;
    T                       *      result_;
    boost::exception_ptr           error_;
    bool                           break_;

	void run_()
	{
		try
		{ iterate(); }
		catch (...)
		{ error_ = current_exception(); }
	}

protected:
	virtual void iterate() = 0;

    void increment()
    {
        BOOST_ASSERT( ! break_);
        BOOST_ASSERT( ! ctx_.is_complete() );

        ctx_.resume();
        if ( break_ || ctx_.is_complete() )
            result_ = 0;
        if ( error_)
            rethrow_exception( error_);
    }

    void yield_return( T const& v)
    {
        result_ = const_cast< T * >( & v);
        ctx_.suspend();
        result_ = 0;
    }

    void yield_break()
    {
        result_ = 0;
        break_ = true;
        ctx_.suspend();
    }

public:
	typedef T	value_type;

    yield_adapter(
			bool do_unwind,
			std::size_t stacksize = boost::contexts::stack_helper::default_stacksize() ) : 
        use_count_( 0),
        ctx_(
            & yield_adapter::run_, this,
            boost::contexts::protected_stack( stacksize),
            do_unwind),
        result_( 0),
        error_(),
        break_( false)
    {}

    friend inline void intrusive_ptr_add_ref( yield_adapter * p)
    { ++p->use_count_; }

    friend inline void intrusive_ptr_release( yield_adapter * p)
    { if ( --p->use_count_ == 0) delete p; }
};

template< typename T >
class yield_iterator : public std::iterator< std::forward_iterator_tag, typename T::value_type >
{
private:
    intrusive_ptr< T >  impl_;

public:
    yield_iterator() : 
		impl_()
    {}

#define BOOST_YI_ARG(z, n, unused) BOOST_PP_CAT(A, n) BOOST_PP_CAT(a, n)

#define BOOST_YI_ARGS(n) BOOST_PP_ENUM(n, BOOST_YI_ARG, ~)

#define BOOST_YI_CTOR(z, n, unused) \
    template< BOOST_PP_ENUM_PARAMS(n, typename A) > \
    yield_iterator( BOOST_YI_ARGS(n) ) : \
        impl_( new T( BOOST_PP_ENUM_PARAMS(n, a) ) ) \
    { impl_->increment(); }

#ifndef BOOST_YI_ARITY
#define BOOST_YI_ARITY 10
#endif

BOOST_PP_REPEAT_FROM_TO( 1, BOOST_YI_ARITY, BOOST_YI_CTOR, ~)

#undef BOOST_YI_CTOR
#undef BOOST_YI_ARGS
#undef BOOST_YI_ARG

    yield_iterator & operator++()
    {
        impl_->increment();
        return * this;
    }

    yield_iterator & operator++( int)
    {
        impl_->increment();
        return * this;
    }

    bool operator==( yield_iterator const& other)
    {
        if ( impl_ == other.impl_)
            return true;
        if ( impl_ && other.impl_)
        {
            if ( impl_->result_ && other.impl_->result_)
                return * impl_->result_ == * other.impl_->result_;
            else
                return impl_->result_ == other.impl_->result_;
        }
        if ( ! impl_)
            return ! other.impl_->result_;
        if ( ! other.impl_)
            return ! impl_->result_;
        return false;
    }

    bool operator!=( yield_iterator const& other)
    { return ! ( * this == other); }

    typename std::iterator_traits< yield_iterator< T > >::value_type const& operator*() const
    { return * ( impl_->result_); }

    typename std::iterator_traits< yield_iterator< T > >::value_type const* operator->() const
    { return impl_->result_; }

    typename std::iterator_traits< yield_iterator< T > >::value_type & operator*()
    { return * ( impl_->result_); }

    typename std::iterator_traits< yield_iterator< T > >::value_type * operator->()
    { return impl_->result_; }
};

}

# if defined(BOOST_MSVC)
# pragma warning(pop)
# endif


#endif // BOOST_YIELD_ITERATOR_H
