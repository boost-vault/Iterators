#include <vector>
#include <list>
#include <deque>
#include "boost/iterator/rebind_tree.hpp"
#include <boost/type_traits/is_same.hpp>
#include <boost/test/unit_test.hpp>
#include "heirarchy.hpp"

using namespace boost;
void test(void)
{
    typedef int src_val0_type;
    typedef heirarchy<src_val0_type> src_heir;
    typedef value_type_nester<src_heir::val3> nest3;
    typedef mpl::begin<nest3>::type iter3;
    BOOST_CHECK((is_same< mpl::deref<iter3>::type, src_heir::val3 >::value));
    typedef mpl::next<iter3>::type iter2;
    BOOST_CHECK((is_same< mpl::deref<iter2>::type, src_heir::val2 >::value));
    typedef mpl::next<iter2>::type iter1;
    BOOST_CHECK((is_same< mpl::deref<iter1>::type, src_heir::val1 >::value));
    typedef mpl::size<nest3> size_type;
    BOOST_CHECK(size_type::value == 3);
    typedef double tar_val0_type;
    typedef heirarchy<tar_val0_type> tar_heir;
    typedef rebind_level<src_heir::val1, tar_heir::val0>::type tar_val1_type;
    BOOST_CHECK((is_same< tar_val1_type, tar_heir::val1 >::value));
    typedef rebind_level<src_heir::val2, tar_heir::val1>::type tar_val2_type;
    BOOST_CHECK((is_same< tar_val2_type, tar_heir::val2 >::value));
    typedef rebind_level<src_heir::val3, tar_heir::val2>::type tar_val3_type;
    BOOST_CHECK((is_same< tar_val3_type, tar_heir::val3 >::value));
    typedef rebind_tree<src_heir::val3, tar_val0_type>::type tar_tree_type;
    BOOST_CHECK((is_same< tar_val3_type, tar_tree_type >::value));
}

namespace butf = boost::unit_test_framework;
butf::test_suite* init_unit_test_suite(int argc, char* argv[])
{
    butf::test_suite* tests = BOOST_TEST_SUITE("nested_value_type_mpl_iterator tests");
    tests->add(BOOST_TEST_CASE(&test));
    return tests;
}
