//simple container heirarchy for use in some tests
#ifndef LIBS_ITERATOR_TEST_HEIRARCHY_HPP_INCLUDED
  template
  < typename Leaf
  >
  struct
heirarchy
{
    typedef Leaf val0;
    typedef std::deque<val0> val1;
    typedef std::list<val1> val2;
    typedef std::vector<val2> val3;
    static unsigned const depth=3;
};
#endif
