#include <iostream>
#include <iomanip>
#include "boost/iterator/flatten_value_type_iterator.hpp"
#include <vector>
#include <list>
#include <deque>
  template
  < typename Parent
  , unsigned MaxDepth
  , unsigned Rank
  >
  struct
tree
{
        typedef
      unsigned const
    shape_type[MaxDepth]
    ;
        static
      void
    fill
      ( unsigned& filler
      , shape_type& shape
      , Parent& parent
      )
    {
        typedef typename Parent::value_type child_type;
        typedef tree<child_type,MaxDepth,Rank-1> child_tree_type;
        unsigned const n=shape[Rank-1];
        for(unsigned i=0; i<n; ++i)
        {
            child_type l_child;
            parent.push_back(l_child);
            child_tree_type::fill(filler, shape, parent.back());
        }
    }
        static
      void
    print
      ( Parent const& parent
      )
    {
        typedef typename Parent::value_type child_type;
        typedef tree<child_type,MaxDepth,Rank-1> child_tree_type;
        typedef typename Parent::const_iterator parent_iter_type;
        parent_iter_type cur=parent.begin();
        parent_iter_type end=parent.end();
        unsigned const border=2;
        unsigned const width=border*(MaxDepth-Rank+1);
        for(bool first=true; cur != end; ++cur,first=false)
        {
            child_type const& l_child=*cur;
            if(first)
            {
                std::cout<<std::setw(border)<<"{ ";
            }
            else
            {
                std::cout<<std::setw(width)<<", ";
            }
            child_tree_type::print(l_child);
        }
        std::cout<<std::setw(width)<<"}\n";
    }
};
  
  template
  < typename Parent
  , unsigned MaxDepth
  >
  struct
tree
  < Parent
  , MaxDepth
  , 1
  >
{
        typedef
      unsigned const
    shape_type[MaxDepth]
    ;
        static
      unsigned const
    Rank
    =1
    ;
        static
      void
    fill
      ( unsigned& filler
      , shape_type& shape
      , Parent& parent
      )
    {
        typedef typename Parent::value_type child_type;
        unsigned const n=shape[Rank-1];
        for(unsigned i=0; i<n; ++i)
        {
            child_type l_child(filler++);
            parent.push_back(l_child);
        }
    }
        static
      void
    print
      ( Parent const& parent
      )
    {
        typedef typename Parent::value_type child_type;
        typedef typename Parent::const_iterator parent_iter_type;
        parent_iter_type cur=parent.begin();
        parent_iter_type end=parent.end();
        unsigned const border=2;
        std::cout<<std::setw(border)<<"{ ";
        for(bool first=true; cur != end; ++cur,first=false)
        {
            child_type const& l_child=*cur;
            if(!first) std::cout<<std::setw(border)<<", ";
            std::cout<<std::setw(3)<<l_child;
        }
        std::cout<<std::setw(border)<<"}\n";
    }
};
  
#include <boost/test/unit_test.hpp>
#include <boost/type_traits/is_same.hpp>
using namespace boost;
void test_types(void)
{
    typedef std::vector<int> tree1_type;
    typedef flatten_value_type_iterator<tree1_type> flat1_iter_type;
    typedef flatten_value_type_iterator_node<tree1_type,has_no_nested_value_type> node1_type;
    BOOST_CHECK((is_same< flat1_iter_type::super_type, node1_type>::value));
    typedef std::list<tree1_type> tree2_type;
    typedef flatten_value_type_iterator<tree2_type> flat2_iter_type;
    typedef flatten_value_type_iterator_node<tree2_type,node1_type> node2_type;
    flat2_iter_type::super_type*s=static_cast<node2_type*>(0);
    BOOST_CHECK((is_same< flat2_iter_type::super_type, node2_type>::value));
}

template<typename ParentBottom, unsigned Depth>
struct print_flatten_iterator_descendants
  : public print_flatten_iterator_descendants<ParentBottom, Depth-1>
{
        typedef
      print_flatten_iterator_descendants<ParentBottom, Depth-1>
    super_type
    ;
        typedef
      typename super_type::btm_iter_type
    btm_iter_type
    ;
    print_flatten_iterator_descendants(btm_iter_type& a_iter)
      : super_type(a_iter)
    {
        unsigned const l_depth=Depth-1;
        typedef flatten_value_type_iterator_child_at<ParentBottom,l_depth> child_at_type;
        typedef typename child_at_type::child_type child_type;
        child_type& a_flat_iter=child_at_type::get_child(a_iter);
        std::cout<<"==>print increment_generation("<<l_depth<<"):\n{";
        for
          ( bool first=true
          ; !a_flat_iter.is_empty()
          ; a_flat_iter.increment_my_generation(),first=false
          )
        {
            typedef typename child_type::top_type top_type;
            std::cout<<(first?" ":", ");
            std::cout<<a_flat_iter.top_type::deref();
        }
        std::cout<<"}\n";
    }
};

template<typename ParentBottom>
struct print_flatten_iterator_descendants<ParentBottom,0>
{
        typedef
      flatten_value_type_iterator<ParentBottom>
    btm_iter_type
    ;
    print_flatten_iterator_descendants(btm_iter_type&)
    {}
};

#include "heirarchy.hpp"

void test_print(void)
{
    typedef heirarchy<int> heir_type;
    typedef heir_type::val3 tree_type;
    tree_type l_tree;
    unsigned filler=0;
    unsigned const max_depth=heir_type::depth;
    unsigned const shape[max_depth]={2,3,4};
    tree<tree_type,max_depth,max_depth>::fill(filler,shape,l_tree);
    std::cout<<"==>print tree:\n";
    tree<tree_type,max_depth,max_depth>::print(l_tree);
    typedef flatten_value_type_iterator<tree_type> flat_iter_type;
    {
        std::cout<<"==>print operator++:\n{";
        flat_iter_type a_flat_iter(l_tree);
        for
          ( bool first=true
          ; !a_flat_iter
          ; ++a_flat_iter,first=false
          )
        {
            std::cout<<(first?" ":", ");
            std::cout<<*a_flat_iter;
        }
        std::cout<<"}\n";
    }
    for(unsigned generation=0; generation < max_depth; ++generation)
    {
        std::cout<<"==>print increment_generation("<<generation<<"):\n{";
        flat_iter_type a_flat_iter(l_tree);
        for
          ( bool first=true
          ; !a_flat_iter
          ; a_flat_iter.increment_generation(generation),first=false
          )
        {
            std::cout<<(first?" ":", ");
            std::cout<<*a_flat_iter;
        }
        std::cout<<"}\n";
    }
    {
        std::cout<<"==>print generations using *descendants:\n\n";
        flat_iter_type a_flat_iter(l_tree);
        typedef print_flatten_iterator_descendants<tree_type, max_depth> print_iter_type;
        print_iter_type l_print_iter(a_flat_iter);
    }
}

#include "boost/iterator/transform_tree.hpp"

static float int2float_half(int a_int)
{
    return float(a_int)+0.5;
}    
void test_transform(void)
{
    typedef int src_type;
    typedef heirarchy<src_type> src_heir_type;
    typedef src_heir_type::val3 src_tree_type;
    src_tree_type l_src_tree;
    unsigned filler=0;
    unsigned const max_depth=src_heir_type::depth;
    unsigned const shape[max_depth]={2,3,4};
    tree<src_tree_type,max_depth,max_depth>::fill(filler,shape,l_src_tree);
    std::cout<<"==>print src_tree:\n";
    tree<src_tree_type,max_depth,max_depth>::print(l_src_tree);
    typedef float tar_type;
    typedef rebind_tree<src_tree_type,tar_type>::type tar_tree_type;//target tree type
    tar_tree_type l_tar_tree=transform_tree(l_src_tree,int2float_half);
    std::cout<<"==>print tar_tree:\n";
    tree<tar_tree_type,max_depth,max_depth>::print(l_tar_tree);
}
    
//}tests
namespace butf = boost::unit_test_framework;
butf::test_suite* init_unit_test_suite(int argc, char* argv[])
{
    butf::test_suite* tests = BOOST_TEST_SUITE("flatten_value_type_iterator tests");
    //tests->add(BOOST_TEST_CASE(&test_types));
    //tests->add(BOOST_TEST_CASE(&test_print));
    tests->add(BOOST_TEST_CASE(&test_transform));
    return tests;
}
