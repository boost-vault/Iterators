//from heirarchy of containers type, creates similar heirarchy but with leaf type rebound.
#ifndef BOOST_ITERATOR_REBIND_TREE_HPP_LJE20050113
#define BOOST_ITERATOR_REBIND_TREE_HPP_LJE20050113
//  (C) Copyright Larry Evans 2006.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
#include "boost/iterator/nested_value_type_mpl_iterator.hpp"
#include "boost/mpl/application_parts_stl_def_alloc.hpp"
#include <boost/mpl/apply.hpp>
#include <boost/mpl/reverse_fold.hpp>
#include <boost/mpl/front.hpp>
#include <boost/mpl/back.hpp>
  template
  < typename Parent
  , typename Child
  >
  struct
rebind_level
{
        typedef typename
      boost::mpl::application_parts<Parent>::type
    parts_type
    ;
        typedef typename
      boost::mpl::front<parts_type>::type
    binary_placeholder_type
    ;
        typedef typename
    #if 1
      std::allocator<Child> 
    //^Kludge to work around #else part not working.
    #else
      boost::mpl::back<parts_type>::type  
    //^FIXME.  This gets wrong type as shown by running 
    // <boost-root>/libs/iterator/test/
    // nested_value_type_mpl_iterator_test.cpp.
    #endif
    last_type
    ;
        typedef typename
      boost::mpl::apply<binary_placeholder_type,Child,last_type>::type
    type
    ;
};
  template
  < typename SrcTree
  , typename NewLeaf
  >
  struct
rebind_tree
{
        typedef
      value_type_nester<SrcTree>
    src_nester_type
    ;
        typedef typename
      boost::mpl::reverse_fold
      < src_nester_type
      , NewLeaf
      , rebind_level<boost::mpl::arg<2>,boost::mpl::arg<1> >
      >::type
    type
    ;
};
#endif
