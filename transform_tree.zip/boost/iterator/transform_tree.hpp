//Purpose:
//  Attempt to solve problem posted by Greg Buchholz in
//  post with headers:
/*
From: "Greg Buchholz" <sleepingsquirrel@yahoo.com>
Newsgroups: comp.lang.c++.moderated
Subject: Typelists, template function specialization, generic programming.
Date: 22 Mar 2006 10:30:36 -0500
 */
 
//ChangeLog:
//  2006-04-01.1037
//    WHAT:
//      Used templated struct instead of templated function.
//    WHY:
//      Allow use of partial specialization.

#include "boost/iterator/rebind_tree.hpp"
  
//Here is the "transform_tree" struct, which should take an arbitrarily
//nested lists of lists of lists... and recursively apply a function
//to each member of the lists of lists of lists...

//Recursive Case: Should be used with nested lists
  template
  < class TreeSrc
  , class In
  , class Out
  >
  struct
transform_tree_impl
{
        static
      typename rebind_tree<TreeSrc,Out>::type
    fmap
      ( TreeSrc const& l
      , Out (*f)(In)
      )
    {
        typedef typename rebind_tree<TreeSrc,Out>::type tree_sink_type;
        tree_sink_type sink_tree;
    
        for
        ( typename TreeSrc::const_iterator iter = l.begin()
        ; iter != l.end()
        ; ++iter
        )
        {
            typename tree_sink_type::value_type l_child=
              transform_tree_impl<typename TreeSrc::value_type,In,Out>::fmap(*iter,f);
            sink_tree.push_back(l_child);
        }
        return sink_tree;
    }
};    
    
//Base Case: No further calls to "fmap"
  template
  < class In
  , class Out
  >
  struct
transform_tree_impl
  < In
  , In
  , Out
  >
{
        static
      Out
    fmap
      ( In l
      , Out (*f)(In)
      )
    {
        return f(l);
    }
};    

  template
  < class TreeSrc
  , class In
  , class Out
  >
  typename rebind_tree<TreeSrc,Out>::type
transform_tree
  ( TreeSrc const& l
  , Out (*f)(In)
  )
{
    return transform_tree_impl<TreeSrc,In,Out>::fmap(l,f);
}    

