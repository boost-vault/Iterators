//defines mpl iterator over the value types of a heirarchy of containers.
#ifndef BOOST_ITERATOR_NESTED_VALUE_TYPE_MPL_ITERATOR_HPP_LJE20050113
#define BOOST_ITERATOR_NESTED_VALUE_TYPE_MPL_ITERATOR_HPP_LJE20050113
//  (C) Copyright Larry Evans 2006.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
#include <boost/mpl/begin_end.hpp>
#include <boost/mpl/next.hpp>
#include <boost/mpl/deref.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/iterator_tags.hpp>
#include <boost/mpl/has_xxx.hpp>
#include <boost/mpl/eval_if.hpp>

BOOST_MPL_HAS_XXX_TRAIT_DEF(value_type)

template
  < class ValueTypeNester
  >
  struct
nested_value_type_mpl_iterator
{
    typedef boost::mpl::forward_iterator_tag category;
    typedef nested_value_type_mpl_iterator type;
};

template
  < class ValueTypeNester
  >
  struct
value_type_nester
/**@brief
 *  "Labels" ValueTypeNester so that begin and end,
 *  when applied to value_type_nester<ValueTypeNester>,
 *  will produce the correct iterator.
 */
{
};

  struct
has_no_nested_value_type
/**@brief
 * "Sentinal" value indicating end of iterator.
 */
{
    typedef has_no_nested_value_type type;
};

namespace boost { namespace mpl {

/**@brief
 *  The purpose of the following 4 template  metafunctions
 *  is so that the sequence of values produced by iterating 
 *  from:
 *    begin<value_type_nester<VTN_0> > 
 *  to:
 *    end<value_type_nester<VTN_0> > 
 *  is:
 *      VTN_0
 *      VTN_1
 *      VTN_2
 *      ...
 *      VTN_n
 *  such that:
 *    VTN_i+1 == VTN_i::value_type
 *  and where n is the smallest unsigned i such that:
 *    !has_value_type<VTN_i>
 */

template <class ValueTypeNester>
struct deref<nested_value_type_mpl_iterator<ValueTypeNester> >
{
    typedef ValueTypeNester type;
};

template <class ValueTypeNester>
struct next<nested_value_type_mpl_iterator<ValueTypeNester> >
{
        typedef typename
      eval_if
      < and_
        < has_value_type<ValueTypeNester>
        , has_value_type<typename ValueTypeNester::value_type>
        >
      , nested_value_type_mpl_iterator<typename ValueTypeNester::value_type>
      , has_no_nested_value_type
      >::type
    type
    ;
};

template<typename ValueTypeNester>
struct begin<value_type_nester<ValueTypeNester> >
{
    typedef nested_value_type_mpl_iterator<ValueTypeNester> type;
};

template<typename ValueTypeNester>
struct end<value_type_nester<ValueTypeNester> >
{
    typedef has_no_nested_value_type type;
};

}}//exit boost::mpl namespace

#endif
