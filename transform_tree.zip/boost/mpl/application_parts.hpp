#ifndef BOOST_MPL_APPLICATION_PARTS_HPP_INCLUDED
#define BOOST_MPL_APPLICATION_PARTS_HPP_INCLUDED
//  (C) Copyright Larry Evans 2005.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
#include <boost/mpl/vector.hpp>
#include <boost/mpl/arg.hpp>
namespace boost{ namespace mpl{

/**@brief
 *  metafunction which, for an application:
 *    T1<T2,T3,...,Tn>
 *  returns:
 *    vector<T1<arg<1>,arg<2>,...,arg<n> >,T2,T3,...,Tn>
 *  for n in {3..5}
 */
template
< class Application
>
struct application_parts
;

template
< class T1
>
struct application_parts
{
    typedef vector<T1> type;
};

template
< template
  < class
  > class T1
, class T2
>
struct application_parts
< T1<T2>
>
{
    typedef vector<T1<arg<1> >,T2> type;
};

template
< template
  < class
  , class
  > class T1
, class T2
, class T3
>
struct application_parts
< T1<T2,T3>
>
{
    typedef vector<T1<arg<1>,arg<2> >,T2,T3> type;
};

template
< template
  < class
  , class
  , class
  > class T1
, class T2
, class T3
, class T4
>
struct application_parts
< T1<T2,T3,T4>
>
{
    typedef vector<T1<arg<1>,arg<2>,arg<3> >,T2,T3,T4> type;
};

template
< template
  < class
  , class
  , class
  , class
  > class T1
, class T2
, class T3
, class T4
, class T5
>
struct application_parts
< T1<T2,T3,T4,T5>
>
{
    typedef vector<T1<arg<1>,arg<2>,arg<3>,arg<4> >,T2,T3,T4,T5> type;
};

}}//exit boost::mpl namespace
#endif
