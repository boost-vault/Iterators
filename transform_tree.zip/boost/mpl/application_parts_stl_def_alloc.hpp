#ifndef BOOST_MPL_APPLICATION_PARTS_STL_DEF_ALLOC_HPP_INCLUDED
#define BOOST_MPL_APPLICATION_PARTS_STL_DEF_ALLOC_HPP_INCLUDED
//  (C) Copyright Larry Evans 2006.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
#include "boost/mpl/application_parts.hpp"
#include <memory>
namespace boost{ namespace mpl{

  /**@brief
   *  The following specializations enable handling of
   *  stl templates which have a default 2nd argument,
   *  std::allocator<Element>, where Element is the 1st argument 
   *  to the stl template (e.g. std::vector).
   *
   *  Without these specializations, the compiler will
   *  claim ambiguity about which application_parts
   *  specialization to use.
   */

template
< class T2
, template
  < class
  , class=std::allocator<T2>
  > class T1
>
struct application_parts
< T1<T2,std::allocator<T2> >
>
{
    typedef std::allocator<T2> T3;
    typedef vector<T1<arg<1>,arg<2> >,T2,T3> type;
};

}}//exit boost::mpl namespace
#endif
