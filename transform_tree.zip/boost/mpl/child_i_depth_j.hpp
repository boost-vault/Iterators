#ifndef BOOST_MPL_CHILD_I_DEPTH_J_HPP_INCLUDED
#define BOOST_MPL_CHILD_I_DEPTH_J_HPP_INCLUDED
//  (C) Copyright Larry Evans 2005.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
#include <boost/mpl/application_parts.hpp>
#include <boost/mpl/at.hpp>
#include <boost/mpl/int.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/apply.hpp>
namespace boost{ namespace mpl{

/**@brief
 *  Binary metafunction which returns ChildIndex-th child
 *  of an application (as defined in application_parts.hpp).
 *  NOTE: 0-th child is the function, not the 1st arg of
 *  the application.
 */
  template
  < class Application
  , class ChildIndex
  , class AppParts=application_parts<arg<1> >
  >
  struct
child_i_depth_1
{
        typedef
      typename apply1<AppParts,Application>::type
    app_type
    ;
        typedef
      typename app_type::type
    parts_type
    ;
        typedef
      typename at<parts_type,ChildIndex>::type
    type
    ;
};

/**@brief
 *  Repeats child_i_depth_1 for DepthIndex times to
 *  first argument.
 */
  template
  < class Application
  , class ChildIndex
  , class DepthIndex
  , class AppParts=application_parts<arg<1> >
  >
  struct
child_i_depth_j
;
  template
  < class Application
  , class ChildIndex
  , class DepthIndex
  , class AppParts
  >
  struct
child_i_depth_j
  : public child_i_depth_j
    < typename child_i_depth_1<Application,ChildIndex,AppParts>::type
    , ChildIndex
    , typename prior<DepthIndex>::type
    , AppParts
    >
{
};

/**@brief
 *  Specialization which returns 1st argument.
 */
  template
  < class Application
  , class ChildIndex
  , class AppParts
  >
  struct
child_i_depth_j
  < Application
  , ChildIndex
  , int_<0>
  , AppParts
  >
{
        typedef
      Application
    type
    ;
};

}}//exit boost::mpl namespace
#endif
